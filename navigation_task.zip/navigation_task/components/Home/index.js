import React,{Component} from 'react'
import {View,Text,TextInput} from 'react-native'
class Home extends Component{
  render(){
    return(
      <View>
      <Text>
      Login in to the APplication
      </Text>
      <TextInput />
       <TextInput />
      </View>  
    )
  }
}